#!/bin/bash
#List of nodes and users
export nodes=${nodes:-"ci-user@10.64.118.99 ci-user@10.64.118.100 ci-user@10.64.119.99"}
# List of passwords in case of the same password for all servers one password
export passwords=${passwords:-""}
# If it practically impossible to set an array as an environment variable
# from a script, so assume variable is a string then convert it to an array
export pass_array=($passwords)

#Server Role: a master i data node ai master and data node
export roles="ai i i"
export NUM_NODES=${NUM_NODES:-3}
export SERVICE_CLUSTER_IP_RANGE=192.168.3.0/24
export FLANNEL_NET=172.16.0.0/16

#proxy if needed
export https_proxy=http://proxy-chain.intel.com:911
export http_proxy=http://proxy-chain.intel.com:911
export PROXY_SETTING="http_proxy=$http_proxy https_proxy=$https_proxy"
#installtion path
export installdir=${installdir:-~}
export kubedir=$installdir/kubernetes

#script will install latest version can use parameters below to use a specific version
#export ETCD_VERSION
#export FLANNEL_VERSION=
#export KUBE_VERSION=1.4.4
