#!/bin/bash

################################################################
# Use this script to set up K8S on your machine  
#
# Usage: set-up-server.sh
#
################################################################

source config.sh

trap 'error ${LINENO}' ERR

DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

error() {
    local parent_lineno="$1"
    local message="$2"
    local code="${3:-1}"
    if [[ -n "$message" ]] ; then
        echo "Error on or near line ${parent_lineno}: ${message}; exiting with status ${code}"
    else
        echo "Error on or near line ${parent_lineno}; exiting with status ${code}"
    fi
    exit "${code}"
}




#check system requirements  copied from dlg code 
if [[ -f "/etc/os-release" ]]; then
    . /etc/os-release
elif [[ -f "/etc/centos-release" ]] && [[ `cat /etc/centos-release | grep "CentOS"` ]]; then
    ID=centos
    VERSION_ID=$(cat /etc/centos-release | grep -oE '[0-9]+\.[0-9]+')
elif [[ `uname -s | grep "Darwin"` ]]; then
    ID=macos
    VERSION_ID=$(sw_vers -productVersion)
else
    printf "Unsupported OS distribution.\nOny Ubuntu, CentOS, CoreOS and macOS are supported\n"
    exit 0
fi
echo Linux distribution: $ID

if [ $ID != "ubuntu" ]; then
   printf "Unsupported OS distribution.\nOny Ubuntu supported\n"
   exit 0
fi 
VER=$(awk -F . '{print $1}' <<< "$VERSION_ID")
curr_pass=N.A
function getServerPass() {
   serverID=$1
   if [ 1 -eq ${#pass_array[@]} ]; then
   	curr_pass=${pass_array[0]} 
   else
       curr_pass=${pass_array[$serverID]}
   fi
}


#verify user has sudo accses
function verify-currenuesr() {
   timeout 2 sudo id && sudo="true" || sudo="no"
   if [ $sudo = "no" ]; then
      echo "current user $USERNAME does not have sudo acsses!"
      exit 1
   fi
} 


passParm=""

function verify-servers () {
	for i in $nodes; do
              echo "validating server $i"
		getServerPass $passID
              passVal=""
	       bash_respond=$(sshpass -p $curr_pass ssh -o StrictHostKeyChecking=no $i "timeout 2 sudo id && echo 'sudo' || echo 'no sudo' ") &&  passVal="" || passVal="fail" 
              passID=$passID+1
              if [[ $passVal = "fail" ]]; then
   		 	echo "Sytem not able to login to $i with password provided!!"
			exit 1
		else
			if [[ "$bash_respond" == *no* ]]; then
                         echo "user is missing sudo acsses premission $i"
                         exit 1
                     fi
		fi             
       done
}




function set-ssh-passwordless(){
    if [ ! -f ~/.ssh/id_rsa	]; then
    	echo "Generating user ssh key"
       ssh-keygen  -t rsa -N '' -f ~/.ssh/id_rsa
    fi
    for i in $nodes; do
              echo "setting passwordless acsses for server $i"
		getServerPass $passID
              sshpass -p $curr_pass ssh-copy-id -o StrictHostKeyChecking=no $i  
              passID=$passID+1                
    done
}




function install-docker(){
    for i in $nodes; do
       echo "install docker $i"
       username=${i%%@*}
	getServerPass $passID
       sshpass -p $curr_pass ssh -o StrictHostKeyChecking=no $i " 
       
       version_gt() {
	   # compare two versions
	     test '$(echo '$@' | tr ' ' '\n' | sort -n | head -n 1)' != '$1';
        }	
        if command -v docker >/dev/null 2>&1; then
           echo 'docker is already installed'
           server_version=$(sudo docker version --format '{{.Server.Version}}') || true
           client_version=$(sudo docker version --format '{{.Client.Version}}') || true
           echo 'docker server version is $server_version'
           echo 'docker client version is $client_version'
        fi
#|| version_gt '1.12' '$server_version' || version_gt '1.12' '$server_version';
        if ! command -v docker >/dev/null 2>&1;  then
                echo 'install latest version of docker'
                sudo sh -c 'export http_proxy=$http_proxy;export https_proxy=$https_proxy;curl -fsSL https://get.docker.com/ | sh'
                sudo usermod -aG docker $username
                if ! sudo service docker status | grep running; then
                    sudo service docker start
                fi            
        fi
    "
    passID=$passID+1                
    done


}


function install-k8s(){
    cd $installdir    
    git clone --depth 1 https://github.com/kubernetes/kubernetes.git
    echo "Download k8s"
    ubuntu/download-release.sh
    sed -i 's/source "${KUBE_ROOT}\/cluster\/common.sh"/#source "${KUBE_ROOT}\/cluster\/common.sh"/' ubuntu/util.sh
    sed -i 's/verify-kube-binaries/#verify-kube-binaries/' kube-up.sh
    cd kubernetes/cluster
    echo "KUBERNETES_PROVIDER=$ID ./kube-up.sh"
    eval "KUBERNETES_PROVIDER=$ID ./kube-up.sh"
    sudo cp ubuntu/binaries/kubectl /usr/bin/
    sudo chmod 777 /usr/bin/kubectl 
}


function configureDockerProxy(){
	if [ $http_proxy != "" ]; then
		for i in $nodes; do
       		echo "set docker proxy $i"
			getServerPass $passID
                     dockerConfigLocation="/etc/default/docker"
			ssh -o StrictHostKeyChecking=no $i "
			if [[ $ID = \"ubuntu\" && $VER -lt \"15\" ]];then
            			if [[ -n \"$http_proxy\" && ! \`cat $dockerConfigLocation | grep \"export http_proxy\"\` ]]; then
                			echo \"setting http proxy for docker (upstart)\"
                			sudo sh -c 'echo \"export http_proxy='$http_proxy'\" >> '$dockerConfigLocation''
                			echo \"sh -c 'echo \"export http_proxy='$http_proxy'\" >> '$dockerConfigLocation''\"
            			fi
            			if [[ -n \"$https_proxy\" && ! \`cat $dockerConfigLocation | grep \"export https_proxy\"\` ]]; then
                			echo \"setting https proxy for docker (upstart)\"
                			sudo sh -c 'echo \"export https_proxy='$https_proxy'\" >> '$dockerConfigLocation''
                			echo \"sh -c 'echo \"export https_proxy='$https_proxy'\" >> '$dockerConfigLocation''\"
            			fi
       		 else
            			if [[ $isDockerProxyNeeded=\"true\" && ! \`cat /etc/systemd/system/docker.service.d/http-proxy.conf | grep \"HTTPS_PROXY\"\` ]];then
                			echo \"setting proxy for docker (systemd)\"
                			sh -c 'mkdir -p /etc/systemd/system/docker.service.d'
                			sh -c 'echo [Service]' > /etc/systemd/system/docker.service.d/http-proxy.conf
                			sh -c 'echo '$dockerProxy'' >> /etc/systemd/system/docker.service.d/http-proxy.conf
                			systemctl daemon-reload
            			fi
        		fi
                     sudo service docker restart
			"
		 passID=$passID+1                
               done
       fi
	
}

function addons() {
      echo "Deploy Kube-DNS,Dashborad"
      cd $kubedir/cluster/ubuntu
      KUBERNETES_PROVIDER=ubuntu ./deployAddons.sh
      kubectl cluster-info

      kubectl create -f $DIR/heapster-controller.yaml
      kubectl create -f $kubedir/cluster/addons/cluster-monitoring/influxdb/grafana-service.yaml  
  
      kubectl create -f $kubedir/cluster/addons/cluster-monitoring/influxdb/heapster-service.yaml  
      kubectl create -f $kubedir/cluster/addons/cluster-monitoring/influxdb/influxdb-grafana-controller.yaml  
      kubectl create -f $kubedir/cluster/addons/cluster-monitoring/influxdb/influxdb-service.yaml
      kubectl cluster-info     
}

# check user has sudo acsses premission
verify-currenuesr
# install git and sshpass 
sudo apt-get -y install git sshpass
# verify that all servers user has acsses and sudo premission 
verify-servers
echo "server validated"
# set ssh passwordless acsses (need for k8s set up script)
set-ssh-passwordless
# install docker if does not exists
install-docker
# install K8S
install-k8s
# configure docker proxy if needed
configureDockerProxy
# deploy K8S addons KUBE-DNS,dashboard,montoring  
addons 

