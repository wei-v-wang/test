# Kubernetes-setup

This scripts can be used to set up a Kubernetes cluster on a cluster on ubuntu servers
based on https://github.com/kubernetes/kube-deploy/tree/master/docker-multinode

#Prerequisites#

1.All machines can communicate with each other.
2.linux machine with Docker 1.10.0 or higher. (script was tested on 1.13.0)


##Installtion script  steps :



#Setup a Kubernetes Master

Download the installtion package
    
    wget http://aa-artifactory.intel.com:8081/artifactory/infra-snapshot-local/aa/intel/com/Kubernetes-setup/1.0-SNAPSHOT/Kubernetes-setup-1.0-SNAPSHOT.tar

Untar package 
    tar -xvf Kubernetes-setup-1.0-SNAPSHOT.tar

    
###Configure and start the Kubernetes cluster
cd Kubernetes-setup/kube-deploy
Use file k8sconfig.sh to control the set up

Configuration example:
      
      # if set to empty will get latest stable version
      export K8S_VERSION=v1.5.2
      # FLANNEL network IP Range
      export FLANNEL_NETWORK=${FLANNEL_NETWORK:-"172.16.0.0/16"}
      #to set up ETCD version defualt 3.0.4
      #export ETCD_VERSION=${ETCD_VERSION:-"3.0.4"}
      #to set up FLANNEL version defulat v0.61
      #FLANNEL_VERSION=${FLANNEL_VERSION:-"v0.6.1"}
      
      #proxy if needed
      #export https_proxy=http://proxy-chain.intel.com:911
      #export http_proxy=http://proxy-chain.intel.com:911
      
      export DEFAULT_IP_ADDRESS=$(ip -o -4 addr list $(ip -o -4 route show to default | awk '{print $5}' | head -1) | awk '{print $4}' | cut -d/ -f1 | head -1)
      export IP_ADDRESS=${IP_ADDRESS:-${DEFAULT_IP_ADDRESS}}
      
      export NO_PROXY=localhost,$IP_ADDRESS,127.0.0.1,$no_proxy
      
      export script_path=${script_path:-"~/Kubernetes-setup/kube-deploy"}
      #Clean up k8s ETCD settings before installing it 
      export REMOVE_ALL=${REMOVE_ALL:-"Y"}
      # where to copy the install files when adding a new cnode to cluster
      export copy_path=~
      #name of the service that will be created on server to start k8s after reboot
      export service_name=${service_name:-"k8s"}
      # if to set up a srvice or not
      export set_up_service=${set_up_service:-"true"}
      #In case of failures how many time to retrie
      export MAR_RETRIES=3


Create Master and single Node

      ./create_cluster.sh -c master
Test setup

      kubectl get nodes

Add a node
      ./create_cluster.sh -c addworker -h [host user and ip : user@10.1.0.0] -p [password] [ add new worker using ssh password]

      ./create_cluster.sh -c addworker -h [host user and ip : user@10.1.0.0] -k [key file path] [ add new worker using ssh key file]

Remove a node
       
       ./create_cluster.sh -c remove [host user and ip : user@10.1.0.0] -p [password] [ Remove k8s installation from current build "
       
       ./create_cluster.sh -c remove [host user and ip : user@10.1.0.0] -k [key file path] [ Remove k8s installation from current build "
    







