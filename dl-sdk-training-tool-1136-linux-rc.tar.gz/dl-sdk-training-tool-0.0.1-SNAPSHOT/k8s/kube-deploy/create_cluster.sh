#!/usr/bin/env bash
#               INTEL CORPORATION PROPRIETARY INFORMATION
#  This software is supplied under the terms of a license agreement or
#  nondisclosure agreement with Intel Corporation and may not be copied
#  or disclosed except in accordance with the terms of that agreement.
#        Copyright (c) 2016-2017 Intel Corporation. All Rights Reserved.
# Script to help set up kubernetes cluster
# set up is based on kubernetes/kube-deployee/docker-multinode
#
# link : https://github.com/kubernetes/kube-deploy/tree/master/docker-multinode

trap 'error ${LINENO}' ERR

DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

error() {
    local parent_lineno="$1"
    local message="$2"
    local code="${3:-1}"
    if [[ -n "$message" ]] ; then
        echo "Error on or near line ${parent_lineno}: ${message}; exiting with status ${code}"
    else
        echo "Error on or near line ${parent_lineno}; exiting with status ${code}"
    fi
    exit "${code}"
}

#check system requirements  copied from dlg code
if [[ -f "/etc/os-release" ]]; then
    . /etc/os-release
elif [[ -f "/etc/centos-release" ]] && [[ `cat /etc/centos-release | grep "CentOS"` ]]; then
    ID=centos
    VERSION_ID=$(cat /etc/centos-release | grep -oE '[0-9]+\.[0-9]+')
elif [[ `uname -s | grep "Darwin"` ]]; then
    ID=macos
    VERSION_ID=$(sw_vers -productVersion)
else
    printf "Unsupported OS distribution.\nOny Ubuntu, CentOS, CoreOS and macOS are supported\n"
    exit 0
fi
echo Linux distribution: $ID

# install git,curl,sshpass for the script to work
#
function install-prerequisites(){
    if [ -n "$(command -v yum)" ]; then
       yum -y install  curl
    fi
    if [ -n "$(command -v apt-get)" ]; then
        apt-get -y install curl
    fi
    if [ -n "$(command -v zypper)" ]; then
       zypper install -y  curl
    fi
}

#verify user has sudo accses
function verify-currenuesr() {
   timeout 2 sudo id && sudo="true" || sudo="no"
   if [ $sudo = "no" ]; then
      echo "current user $USERNAME does not have sudo acsses!"
      exit 1
   fi
}



SETUP_TIMEOUT=120
RETRY_INDEX=0
function setup-master(){
    if [[ "$(id -u)" != "0" ]]; then
        echo "Please run script as root/sudo"
    fi
    #add rule to allow flanel to foward traffic to docker
    iptables -P FORWARD ACCEPT
    source $DIR/k8sconfig.sh

    install-prerequisites
    #download-script
    cd $DIR/docker-multinode
    
    source $DIR/k8sconfig.sh
    # before creating the master run the remove to make sure there are no issues
    
    echo $REMOVE_ALL|./turndown.sh 
    sleep 1
    echo $REMOVE_ALL |./master.sh
    RETRY_INDEX=$((RETRY_INDEX +1))

    if ! [ -x "$(command -v kubectl)" ]; then
        curl -sSL https://storage.googleapis.com/kubernetes-release/release/$K8S_VERSION/bin/linux/amd64/kubectl > /usr/local/bin/kubectl
        chmod +x /usr/local/bin/kubectl
    fi
    echo "Waiting for server....."
    check_time=0
    cluster_ready=false
    while [ $check_time -lt $SETUP_TIMEOUT ] && [ $cluster_ready == "false" ];
    do
        sleep 5
        check_time=$((check_time + 5))
        if /usr/local/bin/kubectl get nodes | grep -q Ready  1>/dev/null 2>/dev/null ;  then
            cluster_ready=true
        else
            echo "Waiting for server....."
        fi
    done
    if [ $cluster_ready == "true" ]; then
        /usr/local/bin/kubectl label nodes $IP_ADDRESS master=true --overwrite
        setup_service "./create_cluster.sh -c master"
        /usr/local/bin/kubectl get nodes --show-labels
    else
        echo "Cluster Setup has failed"
        if [ $RETRY_INDEX -lt $MAR_RETRIES ]; then
            echo "retry installing k8s.."
            setup-master
        else
            echo "install script failed for $MAR_RETRIES times!\nExisting.."
            exit -1
        fi
    fi

}

function install_sshpass(){
    if [  ! "$(command -v sshpass)" ]; then
        if [ -n "$(command -v yum)" ]; then
            yum install -y sshpass
        fi
        if [ -n "$(command -v apt-get)" ]; then
            apt-get -y install sshpass
        fi
    fi

}

function getServerIP(){
    cd $copy_path
    source k8sconfig.sh
    echo $IP_ADDRESS
}
function addSetUPWorker(){
    MASTER_IP=$1
    WORKER_IP=$2
    PASS=$3
    install_sshpass

    verify-server $WORKER_IP $PASS
    cd $script_path
    sshpass -p $PASS scp -o StrictHostKeyChecking=no -r \
    k8sconfig.sh \
    create_cluster.sh \
    k8s_service.sh \
    service_files/service_file \
    service_files/serviced_file \
    docker-multinode \
    $WORKER_IP:$copy_path



    worker_ip=$(sshpass -p $PASS ssh -o StrictHostKeyChecking=no $WORKER_IP "ip -o -4 addr list $(ip -o -4 route show to default | awk '{print $5}' | head -1) | awk '{print $4}' | cut -d/ -f1 | head -1"| awk '{print $4}')

    sshpass -p $PASS ssh -o StrictHostKeyChecking=no $WORKER_IP "sudo sh -c \"
    export http_proxy=$http_proxy
    export https_proxy=$https_proxy
    export service_name=$service_name
    export set_up_service=$set_up_service
    $copy_path/create_cluster.sh -c worker -m $IP_ADDRESS\"
    "
    echo " validating new server ...."
    check_time=0
    server_ready=false
    while [ $check_time -lt $SETUP_TIMEOUT ] && [ $cluster_ready == "false" ];
    do
        sleep 5
        check_time=$((check_time + 5))
        if kubectl get nodes |grep $worker_ip| grep -q Ready ;  then
            cluster_ready=true
        fi
    done
    if [ $cluster_ready == "true" ]; then
        kubectl label nodes  $worker_ip role=worker --overwrite
        kubectl get nodes --show-labels
    else
        echo "Adding server  $WORKER_IP failed !"
        exit -1
    fi

}

# Create service file for K8S restart after boot
#
#
function setup_service(){
    if [ $set_up_service == "true" ]; then
          setup_command=$1
          script_path=/var/lib/$service_name
          mkdir -p $script_path
          cp -f $DIR/create_cluster.sh $script_path
          cp -f $DIR/k8s_service.sh $script_path
          cp -f $DIR/k8sconfig.sh $script_path
          cp -f $DIR/check_bootstarp_status.sh $script_path
          cp -f $DIR/cron_job_handling.sh  $script_path
          eval "cp -fr $DIR/docker-multinode $script_path"
          eval "sed -i 's|##COMMAND##|$setup_command|' $script_path/k8s_service.sh"

          sed -i 's/##SERVICE_NAME##/'$service_name'/' $script_path/k8s_service.sh
          proxy_setting=""
          if [ -n "$https_proxy" ]; then
              proxy_setting="export https_proxy=$https_proxy\n"
          fi
          if [ -n "$http_proxy" ]; then
              proxy_setting="${proxy_setting}export http_proxy=$http_proxy"
          fi
          eval "sed -i 's|##PROXY_SETUP##|$proxy_setting|' $script_path/k8s_service.sh"
          eval "sed -i 's|##K8S_HYPERKUBE_IMAGE##|$K8S_HYPERKUBE_IMAGE|' $script_path/k8s_service.sh"
          eval "sed -i 's|##K8S_BASIC_KEY##|$K8S_BASIC_KEY|' $script_path/k8s_service.sh"
          eval "sed -i 's|##K8S_HYPERKUBE_STARTUP_SCRIPT##|$K8S_HYPERKUBE_STARTUP_SCRIPT|' $script_path/k8s_service.sh"
          eval "sed -i 's|##USE_SECURE_PORT##|$USE_SECURE_PORT|' $script_path/k8s_service.sh"
          create_service

          $DIR/cron_job_handling.sh -c add -f $script_path/check_bootstarp_status.sh
    fi
}


function create_service(){
     service_path=$DIR
     if [ -d "$DIR/service_files" ]; then
          service_path=$DIR/service_files
     fi

     if [ -n "$(command -v systemctl)" ]; then
        cp -f $service_path/serviced_file /etc/systemd/system/${service_name}.service
        sed -i 's/##SERVICE_NAME##/'$service_name'/' /etc/systemd/system/${service_name}.service
        eval "sed -i 's|##K8SPATH##|/var/lib/$service_name|' /etc/systemd/system/${service_name}.service"
        systemctl daemon-reload
        systemctl enable ${service_name}.service
     else
        cp -f $service_path/service_file /etc/init.d/$service_name
        chmod +x /etc/init.d/$service_name
        sed -i 's/##SERVICE_NAME##/'$service_name'/' /etc/init.d/$service_name
        update-rc.d $service_name defaults
     fi

}



function addSetUPWorkerKey(){
    MASTER_IP=$1
    WORKER_IP=$2
    KEYFile=$3
    cd $script_path
    scp -i $KEYFile -o StrictHostKeyChecking=no -r \
    k8sconfig.sh \
    create_cluster.sh \
    k8s_service.sh \
    service_files/service_file \
    service_files/serviced_file \
    docker-multinode \
    $WORKER_IP:$copy_path

    worker_ip=$(ssh -i $KEYFile  -o StrictHostKeyChecking=no $WORKER_IP "ip -o -4 addr list $(ip -o -4 route show to default | awk '{print $5}' | head -1) | awk '{print $4}' | cut -d/ -f1 | head -1"| awk '{print $4}')



    ssh -i $KEYFile $WORKER_IP "sudo sh -c \"
    export http_proxy=$http_proxy
    export https_proxy=$https_proxy
    export service_name=$service_name
    export set_up_service=$set_up_service
    $copy_path/create_cluster.sh -c worker -m $IP_ADDRESS\"
    "

    echo " validating new server ...."

    check_time=0
    server_ready=false
    while [ $check_time -lt $SETUP_TIMEOUT ] && [ $server_ready == "false" ];
    do
        sleep 5
        check_time=$((check_time + 5))
        if kubectl get nodes |grep $worker_ip| grep -q Ready ;  then
            server_ready=true
        fi
    done
    if [ $server_ready == "true" ]; then
        kubectl label nodes  $worker_ip role=worker --overwrite
        kubectl get nodes --show-labels
    else
        echo "Adding server  $WORKER_IP failed !"
        exit -1
    fi
}
function addWorker(){

    if [[ "$(id -u)" != "0" ]]; then
        echo "Please run script as root/sudo"
    fi
    #add rule to allow flanel to foward traffic to docker
    iptables -P FORWARD ACCEPT
    cd $DIR/docker-multinode
    MASTER_IP=$1
    export  MASTER_IP=$MASTER_IP
    source $DIR/k8sconfig.sh

    install-prerequisites
    #download-script

    echo 'Y'|./turndown.sh
    sleep 1
    echo 'Y'|./worker.sh
    setup_service "./create_cluster.sh -c worker -m $MASTER_IP"
}

function verify-server () {

    WORKER_IP=$1
    PASS=$2

    bash_respond=$(sshpass -p $PASS ssh -o StrictHostKeyChecking=no $WORKER_IP "timeout 2 sudo id && echo 'sudo' || echo 'no sudo' ") &&  passVal="" || passVal="fail"
    if [[ $passVal = "fail" ]]; then
                echo "System not able to login to $i with password provided!!"
                exit 1
        else
                if [[ "$bash_respond" == *no* ]]; then
             echo "user is missing sudo acsses premission $i"
             exit 1
        fi
    fi
}

function contains() {
    local n=$#
    local value=${!n}
    for ((i=1;i < $#;i++)) {
        if [ "${!i}" == "${value}" ]; then
            echo "y"
            return 0
        fi
    }
    echo "n"
    return 1
}



function remove(){
     cd $DIR/docker-multinode
     echo 'Y'| ./turndown.sh
     source $DIR/k8sconfig.sh

     k8s_images=("gcr.io/google_containers/hyperkube-amd64"
                 "gcr.io/google_containers/kubernetes-dashboard-amd64"
                 "gcr.io/google_containers/kube-addon-manager-amd64"
                 "gcr.io/google_containers/kubedns-amd64"
                 "gcr.io/google_containers/dnsmasq-metrics-amd64"
                 "gcr.io/google_containers/kube-dnsmasq-amd64"
                 "gcr.io/google_containers/exechealthz-amd64"
                 "gcr.io/google_containers/pause-amd64")
     #remove any image if still exists
     for image in "${k8s_images[@]}"
     do

         if [[ $(docker ps -a | grep $image | awk '{print $1}' | wc -l) != 0 ]]; then
            docker rm -f $(docker ps -a | grep $image | awk '{print $1}')
         fi
     done
     #remove service
     if [ -n "$(command -v systemctl)" ]; then
          if [ -f /etc/systemd/system/${service_name}.service ]; then
            systemctl disable ${service_name}.service
            rm -fr /etc/systemd/system/${service_name}.service
          fi
     else
         update-rc.d -f $service_name remove || true
         rm -fr /etc/init.d/$service_name
     fi

     $DIR/cron_job_handling.sh -c remove -f check_bootstarp_status.sh

     rm -fr /var/lib/$service_name

}


function printhelp(){
  echo "Intel Advanced Analytics script for setting up Kubernetes "
  echo "Usage :"
  echo "./create_cluster.sh -c master [set up k8s master and minion on current machine]"
  echo "./create_cluster.sh -c addworker -h [host user and ip : user@10.1.0.0] -p [password] [ add new worker using ssh password]"
  echo "./create_cluster.sh -c addworker -h [host user and ip : user@10.1.0.0] -k [key file path] [ add new worker using ssh key file]"
  echo "./create_cluster.sh -c remove  [ Remove k8s installation from current build "
  exit 1
}



while [[ $# -gt 1 ]]
do
key="$1"

case $key in
    -c|--command)
    COMMANMD="$2"
    shift # past argument
    ;;
    -h|--host)
    HOST="$2"
    shift # past argument
    ;;
    -p|--password)
    PASSWORD="$2"
    shift # past argument
    ;;
     -k|--keyfile)
    KEYFILE="$2"
    shift # past argument
    ;;
    -m|--mastrip)
    MASTER_HOST="$2"
    shift # past argument
    ;;
     -h|--help)
    PRINT_HELP=true
    shift # past argument
    ;;
    *)
     # echo "unknown option $1"
    #  printhelp      # unknown option
    ;;
esac
shift # past argument or value
done

if [ ! -z $PRINT_HELP ]; then
    printhelp
fi

availableCommands=("master" "addworker" "worker" "remove")
if [ $(contains "${availableCommands[@]}" $COMMANMD) == "n" ]; then
    echo "unknown command option: $COMMANMD"
    printhelp
fi

echo COMMANMD=$COMMANMD
if [ $COMMANMD == "master" ]; then
    setup-master
fi
if [ $COMMANMD == "addworker" ]; then
    source $DIR/k8sconfig.sh
    if [ -z $KEYFILE ]; then
        addSetUPWorker $IP_ADDRESS $HOST $PASSWORD
    else
        addSetUPWorkerKey $IP_ADDRESS $HOST $KEYFILE
    fi
fi
if [ $COMMANMD == "worker" ]; then
    RETRY_INDEX=0
    addWorker $MASTER_HOST
fi
if [ $COMMANMD == "remove" ]; then
    remove
fi