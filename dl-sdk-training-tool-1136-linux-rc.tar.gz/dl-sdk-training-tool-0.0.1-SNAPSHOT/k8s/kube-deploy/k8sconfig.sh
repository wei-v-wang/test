#!/usr/bin/env bash

#               INTEL CORPORATION PROPRIETARY INFORMATION
#  This software is supplied under the terms of a license agreement or
#  nondisclosure agreement with Intel Corporation and may not be copied
#  or disclosed except in accordance with the terms of that agreement.
#        Copyright (c) 2016-2017 Intel Corporation. All Rights Reserved.

# if set to empty will get latest stable version
export K8S_VERSION=v1.5.2

export FLANNEL_NETWORK=${FLANNEL_NETWORK:-"172.16.0.0/16"}
#to set up ETCD version
#export ETCD_VERSION=${ETCD_VERSION:-"3.0.4"}
#to set up FLANNEL version
#FLANNEL_VERSION=${FLANNEL_VERSION:-"v0.6.1"}

#proxy if needed
#export https_proxy=http://proxy-chain.intel.com:911
#export http_proxy=http://proxy-chain.intel.com:911

export DEFAULT_IP_ADDRESS=$(ip -o -4 addr list $(ip -o -4 route show to default | awk '{print $5}' | head -1) | awk '{print $4}' | cut -d/ -f1 | head -1)
export IP_ADDRESS=${IP_ADDRESS:-${DEFAULT_IP_ADDRESS}}

export NO_PROXY=localhost,$IP_ADDRESS,127.0.0.1,$no_proxy

export script_path=${script_path:-"~/Kubernetes-setup/kube-deploy"}

export download_path=${download_path:-"~"}

export REMOVE_ALL=${REMOVE_ALL:-"Y"}

export copy_path=~

export service_name=${service_name:-"k8s"}

export set_up_service=${set_up_service:-"true"}

#In case of failures how many time to retrie
export MAR_RETRIES=3
# Secure port handling
export USE_SECURE_PORT=${USE_SECURE_PORT:-"false"}
export K8S_HYPERKUBE_IMAGE=${K8S_HYPERKUBE_IMAGE:-"gcr.io/google_containers/hyperkube-amd64:v1.5.2"}
export K8S_BASIC_KEY=${K8S_BASIC_KEY:-""}
export K8S_HYPERKUBE_STARTUP_SCRIPT=${K8S_HYPERKUBE_STARTUP_SCRIPT:-""}