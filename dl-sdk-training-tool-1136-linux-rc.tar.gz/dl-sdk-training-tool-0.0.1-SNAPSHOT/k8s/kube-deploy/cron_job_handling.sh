#!/usr/bin/env bash


# This method will check cron job does not exists will add it
#
#
add_cron_job(){
    crontab -l > ./currentCronTab
    addJob="1"

    lines=$(cat ./currentCronTab)

    while read line; do
        if [ "$JOB" == "$line" ]; then
            addJob="0"
            break
        fi
    done <<<"$lines"
    if [ "$addJob" == "1" ]; then
           echo "Adding new cron job to check docker bootstap status"
           echo "$JOB" >> ./currentCronTab
           crontab ./currentCronTab
    fi
    rm ./currentCronTab
}


remove_cron_job(){
    crontab -l | grep -v "$script_file" > ./currentCronTab
    crontab ./currentCronTab
    rm ./currentCronTab
}
while [[ $# -gt 1 ]]
do
key="$1"

case $key in
    -c|--command)
    COMMANMD="$2"
    shift # past argument
    ;;
    -f|--script_file)
    script_file="$2"
    JOB="*/1 * * * * source /etc/profile;$script_file"
    shift # past argument
    ;;
    *)
     # echo "unknown option $1"
    #  printhelp      # unknown option
    ;;
esac
shift # past argument or value
done



if [[ $COMMANMD == "add" ]]; then
    add_cron_job
fi
if [[ $COMMANMD == "remove" ]]; then
    remove_cron_job
fi