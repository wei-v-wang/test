#!/usr/bin/env bash



BOOTSTRAP_DOCKER_SOCK=unix:///var/run/docker-bootstrap.sock

if docker ps | grep -q gcr.io/google_containers/hyperkube-amd64 ; then
        #check that kubernetes is running on server
        if ps aux |grep -v grep | grep -q $BOOTSTRAP_DOCKER_SOCK  ; then
            exit
        else # if docker-bootstrap not running restart docker-bootstrap daemon
            docker daemon \
            -H ${BOOTSTRAP_DOCKER_SOCK} \
            -p /var/run/docker-bootstrap.pid \
            --iptables=false \
            --ip-masq=false \
            --bridge=none \
            --graph=/var/lib/docker-bootstrap \
            --exec-root=/var/run/docker-bootstrap \
            2> /var/log/docker-bootstrap.log \
            1> /dev/null &
        fi
fi
