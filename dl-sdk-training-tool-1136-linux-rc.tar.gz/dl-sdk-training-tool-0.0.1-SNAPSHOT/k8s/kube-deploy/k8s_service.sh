#!/usr/bin/env bash
#               INTEL CORPORATION PROPRIETARY INFORMATION
#  This software is supplied under the terms of a license agreement or
#  nondisclosure agreement with Intel Corporation and may not be copied
#  or disclosed except in accordance with the terms of that agreement.
#        Copyright (c) 2016-2017 Intel Corporation. All Rights Reserved.
# This script  is to be used by the service file
# to start /stop/destroy /status K8S cluster
#

service_name=##SERVICE_NAME##
##PROXY_SETUP##
script_path=/var/lib/$service_name
log_file=/var/log/${service_name}_service.log



function start_service(){
    sleep 10
    #Delete folder /var/lib/kubelet
    mount | grep "/var/lib/kubelet/*" | awk '{print $3}' | xargs umount 1>/dev/null 2>/dev/null
    mount | grep "/var/lib/kubelet/*" | awk '{print $3}' | xargs umount 1>/dev/null 2>/dev/null
    umount -l /var/lib/kubelet 1>/dev/null 2>/dev/null
    umount -l /var/lib/kubelet 1>/dev/null 2>/dev/null
    rm -fr /var/lib/kubelet/plugins
    rm -fr /var/lib/kubelet/pods
    cd $script_path
    export USE_SECURE_PORT="##USE_SECURE_PORT##"
    export K8S_HYPERKUBE_IMAGE="##K8S_HYPERKUBE_IMAGE##"
    export K8S_BASIC_KEY="##K8S_BASIC_KEY##"
    export K8S_HYPERKUBE_STARTUP_SCRIPT="##K8S_HYPERKUBE_STARTUP_SCRIPT##"
    export REMOVE_ALL='N'
    export download_path=$script_path
    export set_up_service=false
    ##COMMAND## | tee $log_file
    id >> $log_file
    if [ -f /usr/local/bin/kubectl ] ; then
        /usr/local/bin/kubectl delete  $(/usr/local/bin/kubectl get secret --namespace=kube-system -o name) --namespace=kube-system 1>> $log_file 2>> $log_file
        /usr/local/bin/kubectl delete  $(/usr/local/bin/kubectl get pod --namespace=kube-system -o name| grep kube-dns) --namespace=kube-system 1>> $log_file 2>> $log_file
        /usr/local/bin/kubectl delete  $(/usr/local/bin/kubectl get pod --namespace=kube-system -o name| grep k8s-proxy) --namespace=kube-system 1>> $log_file 2>> $log_file
    fi
}

function stop_service(){
    cd $script_path/docker-multinode/
    #echo 'N' | ./turndown.sh
    #update-rc.d -f $service_name remove || true
    #rm -fr /etc/init.d/$service_name
    #$script_path/cron_job_handling.sh -c remove -f check_bootstarp_status.sh
}



function service_status(){
    if [ -f /usr/local/bin/kubectl ] ; then
        if kubectl get nodes | grep -q Ready ;  then
            echo "$service_name Running"
        else
            echo "$service_name not running"
        fi
    fi
}

function printhelp(){
    echo "service support start|stop|status"
}


function contains() {
    local n=$#
    local value=${!n}
    for ((i=1;i < $#;i++)) {
        if [ "${!i}" == "${value}" ]; then
            echo "y"
            return 0
        fi
    }
    echo "n"
    return 1
}



while [[ $# -gt 1 ]]
do
key="$1"

case $key in
    -c|--command)
    COMMANMD="$2"
    shift # past argument
    ;;
     -h|--help)
    PRINT_HELP=true
    shift # past argument
    ;;
    *)
     # echo "unknown option $1"
    #  printhelp      # unknown option
    ;;
esac
shift # past argument or value
done

if [ ! -z $PRINT_HELP ]; then
    printhelp
fi

availableCommands=("start" "stop" "status")
if [ $(contains "${availableCommands[@]}" $COMMANMD) == "n" ]; then
    echo "unknown command option: $COMMANMD"

fi





echo COMMANMD=$COMMANMD
if [ $COMMANMD == "start" ]; then
    start_service
fi
if [ $COMMANMD == "stop" ]; then
    stop_service
fi
if [ $COMMANMD == "status" ]; then
    service_status
fi