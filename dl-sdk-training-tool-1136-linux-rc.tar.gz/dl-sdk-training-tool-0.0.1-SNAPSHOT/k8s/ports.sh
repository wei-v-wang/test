#!/bin/bash
validate_ports() {
    #netstat installation
    if [ -n "$(command -v yum)" ]; then
        if [ -z "$(command -v netstat)" ]; then
           yum -y install net-tools > /dev/null 2>&1
        fi
    elif [ -n "$(command -v apt-get)" ]; then
       if [ -z "$(command -v netstat)" ]; then
           apt-get -y install net-tools > /dev/null 2>&1
       fi
    elif [ -n "$(command -v zypper )" ]; then
       if [ -z "$(command -v netstat)" ]; then
            zypper -y install net-tools > /dev/null 2>&1
       fi
    else
        echo "Neither Ubuntu, SUSE nor CentOs are installed on the machine"
        exit 1
    fi

    #checking unavailable ports
    ports=($@)
    echo ${ports[@]}
    busyports=()

    for port in "${ports[@]}"
    do
       line=`netstat -tulenp | grep $port | awk '{print $1, $4, $9}'`
       [ -z "$line" ] && continue
       busyports+=("$line")
    done

    busy_ports_output=""
    is_ports_available=true
    if [ ! -z "$busyports" ]; then
        is_ports_available=false
        busy_ports_output="{\"busy_ports\": ["

        for busyport in "${busyports[@]}"
        do
           PROTO=`echo "$busyport" | awk '{print $1}'`
           HPORT=`echo "$busyport" | awk '{print $2}' | sed 's/.*://g'`
           APP=`echo "$busyport" | awk '{print $3}'`

           if [ "$i" == "${busyports[-1]}" ]
           then
               busy_ports_output+="{"
               busy_ports_output+="\"port\":\"$HPORT\","
               busy_ports_output+="\"protocol\":\"$PROTO\","
               busy_ports_output+="\"app\":\"$APP\""
               busy_ports_output+="}"
           else
               busy_ports_output+="{"
               busy_ports_output+="\"port\":\"$HPORT\","
               busy_ports_output+="\"protocol\":\"$PROTO\","
               busy_ports_output+="\"app\":\"$APP\""
               busy_ports_output+="},"
           fi
        done
        busy_ports_output+="]}"
    fi
}