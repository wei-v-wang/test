#!/bin/bash

################################################################
# Use this script to remove your K8S instltion 
#
# Usage: clean_server.sh 
#
################################################################



# If it practically impossible to set an array as an environment variable
# from a script, so assume variable is a string then convert it to an array

source config.sh

error() {
    local parent_lineno="$1"
    local message="$2"
    local code="${3:-1}"
    if [[ -n "$message" ]] ; then
        echo "Error on or near line ${parent_lineno}: ${message}; exiting with status ${code}"
    else
        echo "Error on or near line ${parent_lineno}; exiting with status ${code}"
    fi
    exit "${code}"
}

trap 'error ${LINENO}' ERR


#check system requirements  copied from dlg code 
if [[ -f "/etc/os-release" ]]; then
    . /etc/os-release
elif [[ -f "/etc/centos-release" ]] && [[ `cat /etc/centos-release | grep "CentOS"` ]]; then
    ID=centos
    VERSION_ID=$(cat /etc/centos-release | grep -oE '[0-9]+\.[0-9]+')
elif [[ `uname -s | grep "Darwin"` ]]; then
    ID=macos
    VERSION_ID=$(sw_vers -productVersion)
else
    printf "Unsupported OS distribution.\nOny Ubuntu, CentOS, CoreOS and macOS are supported\n"
    exit 0
fi
echo Linux distribution: $ID

if [ $ID != "ubuntu" ]; then
   printf "Unsupported OS distribution.\nOny Ubuntu supported\n"
   exit 0
fi 

curr_pass=N.A
function getServerPass() {
   serverID=$1
   if [ 1 -eq ${#pass_array[@]} ]; then
   	curr_pass=${pass_array[0]} 
   else
       curr_pass=${pass_array[$serverID]}
   fi
}

#remove pods,services
kubectl delete --all rc
kubectl delete --all deployments
kubectl delete --all pods
kubectl delete --all deployments --namespace=kube-system
kubectl delete --all rc --namespace=kube-system
kubectl delete --all pods --namespace=kube-system


#Remove K8S installtion 
if [ -d $kubedir ]; then
   echo  "Removing  kubernetes instllation"
   cd $kubedir/cluster
   echo "KUBERNETES_PROVIDER=$ID ./kube-down.sh"
   eval "KUBERNETES_PROVIDER=$ID ./kube-down.sh"
   rm -fr $kubedir
   rm -fr ~/kube
fi 

# install sshpass if not exists
sudo apt-get install sshpass

#remove docker from all machines
passID=0
#for i in $nodes; do
#	getServerPass $passID
       sshpass -p $curr_pass ssh -o StrictHostKeyChecking=no $i "
       sudo service docker stop
       sudo apt-get -y purge docker-engine
       sudo apt-get -y autoremove --purge docker-engine
       sudo apt-get -y autoclean
       sudo rm -rf /var/lib/docker
       sudo rm -f /etc/apparmor.d/docker
#       "
#       echo "next line"
#	passID=$passID+1
#done

 
#Remove SSH keys from servers is exists
echo $USER@$HOSTNAME
keyregex=$USER@$HOSTNAME
for i in $nodes; do
       echo "Removing passwordless premission on server $i for $keyregex"
	getServerPass $passID
       sshpass -p $curr_pass ssh -o StrictHostKeyChecking=no $i "
       sed -i '/$keyregex/d' ~/.ssh/authorized_keys
       "
	passID=$passID+1
done