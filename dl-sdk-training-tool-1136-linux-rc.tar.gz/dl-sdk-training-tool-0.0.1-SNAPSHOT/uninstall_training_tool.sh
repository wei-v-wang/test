#!/bin/bash

#               INTEL CORPORATION PROPRIETARY INFORMATION
#  This software is supplied under the terms of a license agreement or
#  nondisclosure agreement with Intel Corporation and may not be copied
#  or disclosed except in accordance with the terms of that agreement.
#        Copyright (c) 2016-2017 Intel Corporation. All Rights Reserved.

# This script removes the Training Tool from local Linux or macOS machine

SCRIPT_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

if ! [ $(id -u) = 0 ]; then
   echo "root permissions are required to run this script"
   exit 1
fi

remove_container() { 
    if docker ps | awk -v app="$1" 'NR > 1 && $NF == app' | grep $1; then
        echo docker stop "$1"
        docker stop "$1"
    fi
    if docker ps -a| awk -v app="$1" 'NR > 1 && $NF == app'| grep $1; then
        echo docker rm "$1"
        docker rm -f "$1"
    fi
}

remove_network(){
    if [[ ! -z $(docker network ls | grep dlsdk_network) ]]; then
        docker network rm dlsdk_network
    fi
}

GROUP_NAME=dlsdk-group
USER_NAME=dlsdk-user

#check system requirements
if [[ -f "/etc/os-release" ]]; then
    . /etc/os-release
elif [[ -f "/etc/centos-release" ]] && [[ `cat /etc/centos-release | grep "CentOS"` ]]; then
    ID=centos
    VERSION_ID=$(cat /etc/centos-release | grep -oE '[0-9]+\.[0-9]+')
elif [[ `uname -s | grep "Darwin"` ]]; then
    ID=macos
    VERSION_ID=$(sw_vers -productVersion)
fi

remove_user_group(){
    if [[ ! $ID = "macos" ]]; then
        if  cat /etc/passwd| grep -q $USER_NAME; then
            userdel  $USER_NAME
        fi
        if   cat /etc/group | grep -q $GROUP_NAME  ; then
            groupdel $GROUP_NAME
        fi
    fi
}

type=multi
if docker ps | grep -q  gcr.io/google_containers/hyperkube-amd64 ; then
    pod_name=$(kubectl get pods | grep dlsdk-master | awk '{print $1}')
    volumePath=$(kubectl describe pod $pod_name| grep Path: | head -1)
    volumePath=${volumePath#*Path:}

    export script_path=k8s/kube-deploy
    export download_path=$SCRIPT_DIR/k8s_install
    export export service_name=dlsdk
    . k8s/kube-deploy/create_cluster.sh -c remove || true
    k8s_images=("gcr.io/google_containers/hyperkube-amd64"
                 "gcr.io/google_containers/kubernetes-dashboard-amd64"
                 "gcr.io/google_containers/kube-addon-manager-amd64"
                 "gcr.io/google_containers/kubedns-amd64"
                 "gcr.io/google_containers/dnsmasq-metrics-amd64"
                 "gcr.io/google_containers/kube-dnsmasq-amd64"
                 "gcr.io/google_containers/exechealthz-amd64"
                 "gcr.io/google_containers/pause-amd64")
     #remove any image if still exists
    for image in "${k8s_images[@]}"
    do
         if [[ $(docker images | grep $image | awk '{print $1}' | wc -l) != 0 ]]; then
            docker rmi -f $(docker images  | grep $image | awk '{print $3}')
         fi
     done
else
    type=single
    # remove containers
    #JS
    if [ "$DLSDK_JS_CONTAINER_NAME" = "" ]
    then
       DLSDK_JS_CONTAINER_NAME=trainingtool-js
    fi
    #Caffe
    if [ "$DLSDK_CAFFE_CONTAINER_NAME" = "" ]
    then
       DLSDK_CAFFE_CONTAINER_NAME=trainingtool-caffe
    fi
    #TF
    if [ "$DLSDK_TF_CONTAINER_NAME" = "" ]
    then
       DLSDK_TF_CONTAINER_NAME=trainingtool-tf
    fi
    #NEON
    if [ "$DLSDK_NEON_CONTAINER_NAME" = "" ]
    then
       DLSDK_NEON_CONTAINER_NAME=trainingtool-neon
    fi
    #ETCD
    if [ "$DLSDK_ETCD_CONTAINER_NAME" = "" ]
    then
       DLSDK_ETCD_CONTAINER_NAME=trainingtool-etcd
    fi

    volumePath=$(docker inspect --format '{{ range .Mounts }}{{ .Source }}{{ end }}' $DLSDK_JS_CONTAINER_NAME)

    remove_container $DLSDK_JS_CONTAINER_NAME
    remove_container $DLSDK_TF_CONTAINER_NAME
    remove_container $DLSDK_NEON_CONTAINER_NAME
    remove_container $DLSDK_ETCD_CONTAINER_NAME
    remove_container $DLSDK_CAFFE_CONTAINER_NAME

fi

# remove saved images
if docker images | grep -q intelcorp/dl-training-tool; then
    docker rmi -f $(docker images | grep intelcorp/dl-training-tool | awk '{print $3}')
fi

remove_user_group
remove_network

if [ -d "$volumePath" ]; then
    read -r -p "Do you want to remove $volumePath folder? [y/n] " response
    if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo "rm -rf $volumePath"
        rm -rf $volumePath
    fi
fi