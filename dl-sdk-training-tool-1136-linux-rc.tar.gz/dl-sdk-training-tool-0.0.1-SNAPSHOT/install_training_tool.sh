#!/bin/bash

#               INTEL CORPORATION PROPRIETARY INFORMATION
#  This software is supplied under the terms of a license agreement or
#  nondisclosure agreement with Intel Corporation and may not be copied
#  or disclosed except in accordance with the terms of that agreement.
#        Copyright (c) 2016-2017 Intel Corporation. All Rights Reserved.


SCRIPT_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
cd $SCRIPT_DIR

function usage {
    echo "$programname script installs Intel Deep Learning Training Tool to local Linux machine"
    echo ""
    echo "Options:"
    echo "-volume path                Linux file system path which should be mounted as a volume inside the docker"
    echo "-toolpassword password      admin password to access the Training Tool web interface"
    echo "-startport port             starting network port range to access the Training Tool web interface"
    echo "-httpproxy  proxy           proxy server for HTTP"
    echo "-httpsproxy proxy           proxy server for HTTPS"
    echo "-type single/multi          single or multi node installation"
    echo "-pfxcertificatepath         path to PFX certificate to access the Training Tool using HTTPS"
    echo "-pfxcertificatepassword     password for PFX certificate"
    echo "-help                       print help message"
    exit 1
}

error() {
    local parent_lineno="$1"
    local message="$2"
    local code="${3:-1}"
    if [[ -n "$message" ]] ; then
        echo "Error on or near line ${parent_lineno}: ${message}; exiting with status ${code}"
    else
        echo "Error on or near line ${parent_lineno}; exiting with status ${code}"
    fi
    exit "${code}"
}

set -o errtrace #  propagate the error trap to functions
trap 'error ${LINENO}' ERR

GROUP_NAME=dlsdk-group
USER_NAME=dlsdk-user
USER_ID=20000
GRP_ID=20000

create_user(){
    if   cat /etc/group | grep -q $GRP_ID  ; then
        groupname=$( cat /etc/group |grep $GRP_ID)
        GROUP_NAME=${groupname%%:*}
    else
        if [[ ! $ID = "macos" ]];then
            echo "groupadd -r $GROUP_NAME -g $GRP_ID"
            groupadd -r $GROUP_NAME -g $GRP_ID
        fi
    fi

    if  cat /etc/passwd| grep -q $USER_ID; then
        username=$( cat /etc/passwd| grep $USER_ID )
        USER_NAME=${username%%:*}
    else
        if [[ ! $ID = "macos" ]];then
            echo "useradd -u $USER_ID -r -g $GROUP_NAME $USER_NAME"
            useradd -u $USER_ID -r -g $GROUP_NAME $USER_NAME
        fi
    fi
}

version_gt() {
    # compare two versions
    test "$(echo "$@" | tr " " "\n" | sort -n | head -n 1)" != "$1";
}

remove_container() {
    if docker ps | awk -v app="$1" 'NR > 1 && $NF == app' | grep $1; then
        echo "docker stop \"$1\""
        docker stop "$1"
    fi
    if docker ps -a| awk -v app="$1" 'NR > 1 && $NF == app'| grep $1; then
        echo "docker rm -f \"$1\""
        docker rm -f "$1"
    fi
}

get_container_ip() {
    docker inspect --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "$@"
    container_ip=
}

EULA_FILE=Intel_Deep_Learing_SDK_EULA.txt

accept_decline_msg="Type \"accept\" to continue or \"decline\" to exit from the install script: "

common_title="License agreement"

license_notice="-------------------------------------------------------------------------------- \n\
To continue with the installation of this product you are required to accept \n\
the terms and conditions of the End User License Agreement (EULA). The EULA \n\
is displayed using the 'more' utility. Press the spacebar to advance to the \n\
next page or enter 'q' to skip to the end. After reading the EULA, you must \n\
enter 'accept' to continue the installation or 'decline' to exit from \n\
the install script.\n\
--------------------------------------------------------------------------------"

if [ ! -f "$EULA_FILE" ]; then
    license_notice="-------------------------------------------------------------------------------- \n\
To continue with the installation of this product you are required to accept \n\
the terms and conditions of the End User License Agreement (EULA), see
Intel_Deep_Learing_SDK_EULA.txt file in the package. After reading the EULA,
you must enter 'accept' to continue the installation or 'decline' to exit from \n\
the install script.\n\
--------------------------------------------------------------------------------"
fi

SHOW_LICENSE() {
    clear
    if [ -f "$EULA_FILE" ]; then
        eula=`cat $EULA_FILE`
    fi
    ECHOE=$(echo -e "");
    if [ -z "${ECHOE}" ]; then
        echo -e "$common_title\n$license_notice\n$eula" | more -d ; echo
    else
        echo "$common_title\n$license_notice\n$eula" | more -d ; echo
    fi
    echo "$LI_license_show_question"
    GET_ACCEPTANCE
}

GET_ACCEPTANCE()
{
    echo -n "$accept_decline_msg"
    read -r ACCEPTANCE > /dev/null 2>&1
    [ ${#ACCEPTANCE} -gt 256 ] && ACCEPTANCE=`expr substr "$ACCEPTANCE" 1 256`;
    ACCEPTANCE=$(echo $ACCEPTANCE | tr [A-Z] [a-z] )
    if [ "$ACCEPTANCE" = decline ] ; then
        echo "You have declined the license agreement. Exit"
        exit
    elif [ "$ACCEPTANCE" != accept ] ; then
        echo "Incorrect input, please try again"
        GET_ACCEPTANCE
    else
        export ACCEPT_EULA="accept"
    fi
}

SHOW_VERSION() {
    if [ -f "version.txt" ]; then
        echo "Installer version: $(cat version.txt)"
    fi
}

#initialize docker name
if [ "$DLSDK_NETWORK_NAME" = "" ]
then
   DLSDK_NETWORK_NAME=dlsdk_network
fi
if [ "$user_subnet_prefix" = "" ]
then
   user_subnet_prefix=170
fi

subnet_prefix=''


create_docker_network()
{
    echo "create docker network..."
    if docker network ls | grep $DLSDK_NETWORK_NAME; then
        echo "remove existing network: $DLSDK_NETWORK_NAME "
        docker network rm $DLSDK_NETWORK_NAME
    fi
    #find the next free subnet
    declare -a arr=()
    while read -r line ;do
        subnet=$(docker network inspect --format '{{range .IPAM.Config}}{{.Subnet}}{{end}}' $line)
        subnet_prefix=${subnet%.*}
        arr+=($subnet_prefix)
    done < <(docker network ls | awk 'NR>=2 {print $2}')

    #if generated subnet ip is not in arr use it for the docker network creation and exit for loop
    for i in `seq 1 255`;
    do
         subnet_prefix=$user_subnet_prefix.$i.0
         if [[ ! " ${arr[@]} " =~ " ${subnet_prefix} " ]]; then
            subnet=$subnet_prefix.0
            echo "docker network create --subnet=$subnet/16 $DLSDK_NETWORK_NAME"
            docker network create --subnet=$subnet/16 $DLSDK_NETWORK_NAME
            break
         fi
    done
}

install_etcd() {
    echo "docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.2 -tid -v $mount_volume:/data --restart=always --name=$DLSDK_ETCD_CONTAINER_NAME  ${DLSDK_ETCD_CONTAINER}"
    docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.2 -tid -v $mount_volume:/data --restart=always --name=$DLSDK_ETCD_CONTAINER_NAME  ${DLSDK_ETCD_CONTAINER}
    etcdHostIP=$subnet_prefix.2
}

install_tensorflow() {
    # run TensorFlow
    echo "docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.3 -tid $dockerContProxy -e ETCD_PORT=$etcd_port -e ETCD_SERVER=$etcdHostIP -e DLSDK_INSTALL_ONLY=false --volume=$mount_volume:/workspace --restart=always --name=$DLSDK_TF_CONTAINER_NAME ${DLSDK_TF_CONTAINER}"
    docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.3 -tid $dockerContProxy -e ETCD_PORT=$etcd_port -e ETCD_SERVER=$etcdHostIP -e DLSDK_INSTALL_ONLY=false --volume=$mount_volume:/workspace --restart=always --name=$DLSDK_TF_CONTAINER_NAME ${DLSDK_TF_CONTAINER}
}

install_job_server() {
    # run JobServer
    caffeHostIP=$subnet_prefix.4
    tfHostIP=$subnet_prefix.3

    echo "docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.5 -tid $dockerContProxy -e ETCD_PORT=$etcd_port -e ETCD_SERVER=$etcdHostIP -e no_proxy=$etcdHostIP -e DLSDK_CAFFE_JUPYTER_PORT=$js_jupyter_caffe_port -e DLSDK_TF_JUPYTER_PORT=$js_jupyter_tf_port -e DLSDK_SELF_SIGNED_CERTIFICATE_ALLOW="$self_sign_certificate" -e DLSDK_PFXCERTIFICATE_ALLOW=$pfx_certificate -e DLSDK_PFXCERTIFICATE_PATH="$pfx_certificate_path" -e DLSDK_PFXCERTIFICATE_PASSWORD="$pfx_certificate_password" -e DLSDK_FILTER_ALLOW="$DLSDK_FILTER_ALLOW" -e DLSDK_USER_ADMIN=$toolpasswordhash -e CAFFE_HOST=$caffeHostIP -e CAFFE_PORT=$caffe_rest_port -e CAFFE_JUPYTER_PORT=$caffe_jupyter_port -e TF_HOST="$tfHostIP" -e TF_PORT="$tf_rest_port" -e TF_JUPYTER_PORT="$tf_jupyter_port" --volume=$mount_volume:/workspace -p $js_ui_port:3000 -p $js_jupyter_caffe_port:3001 -p $js_jupyter_tf_port:3002 --restart=always --name=$DLSDK_JS_CONTAINER_NAME ${DLSDK_JS_CONTAINER}"
    docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.5 -tid $dockerContProxy -e ETCD_PORT=$etcd_port -e ETCD_SERVER=$etcdHostIP -e no_proxy=$etcdHostIP -e DLSDK_CAFFE_JUPYTER_PORT=$js_jupyter_caffe_port -e DLSDK_TF_JUPYTER_PORT=$js_jupyter_tf_port -e DLSDK_SELF_SIGNED_CERTIFICATE_ALLOW=$self_sign_certificate -e DLSDK_PFXCERTIFICATE_ALLOW=$pfx_certificate -e DLSDK_PFXCERTIFICATE_PATH=$pfx_certificate_path -e DLSDK_PFXCERTIFICATE_PASSWORD=$pfx_certificate_password -e DLSDK_FILTER_ALLOW=\"$DLSDK_FILTER_ALLOW\" -e DLSDK_USER_ADMIN=$toolpasswordhash -e CAFFE_HOST="$caffeHostIP" -e CAFFE_PORT="$caffe_rest_port" -e CAFFE_JUPYTER_PORT="$caffe_jupyter_port" -e TF_HOST="$tfHostIP" -e TF_PORT="$tf_rest_port" -e TF_JUPYTER_PORT="$tf_jupyter_port" --volume=$mount_volume:/workspace -p $js_ui_port:3000 -p $js_jupyter_caffe_port:3001 -p $js_jupyter_tf_port:3002 --restart=always --name=$DLSDK_JS_CONTAINER_NAME ${DLSDK_JS_CONTAINER}
}

install_caffe() {
    # fix permissions to docker volume
    if [[ $ID = "macos" ]]; then
        echo "docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix..4 -tid $dockerContProxy -e DLSDK_INSTALL_ONLY=true --volume=$mount_volume:/workspace --restart=always --name=$DLSDK_CAFFE_CONTAINER_NAME_INSTL ${DLSDK_CAFFE_CONTAINER}"
        docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.4 -tid $dockerContProxy -e DLSDK_INSTALL_ONLY=true --volume=$mount_volume:/workspace --restart=always --name=$DLSDK_CAFFE_CONTAINER_NAME_INSTL ${DLSDK_CAFFE_CONTAINER}

        container_id=$(docker ps -q --filter "name=^/${DLSDK_CAFFE_CONTAINER_NAME_INSTL}$")
#
#        chown -R dlsdk-user:dlsdk-group $dl_folder
#
        echo "docker exec -u 0 $container_id sh -c \"rm -f /workspace/dlsdk/security/security.properties\""
        docker exec -u 0 $container_id sh -c "rm -f /workspace/dlsdk/security/security.properties"

        echo "docker exec -u 0 $container_id sh -c \"mkdir -p /workspace/dlsdk/security\""
        docker exec -u 0 $container_id sh -c "mkdir -p /workspace/dlsdk/security"

        if [ "$ui_installer" == "true" ]; then
            echo "docker exec -u 0 $container_id sh -c \"touch /workspace/dlsdk/security/.showPassword\""
            docker exec -u 0 $container_id sh -c "touch /workspace/dlsdk/security/.showPassword"
        fi

        echo "docker exec -u 0 $container_id sh -c \"chown -R dlsdk:docker /workspace\""
        docker exec -u 0 $container_id sh -c "chown -R dlsdk:docker /workspace"

        if [ "$pfx_certificate" = "true" ]; then
            echo "docker cp $pfxcertificatepath $container_id:/workspace/$pfx_certificate_path"
            docker cp $pfxcertificatepath $container_id:/workspace/$pfx_certificate_path
        fi


        docker rm -f $DLSDK_CAFFE_CONTAINER_NAME_INSTL
    fi

    # run Caffe
    echo "docker run --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.4 -tid $dockerContProxy -e ETCD_PORT=$etcd_port -e ETCD_SERVER=$etcdHostIP --device /dev/null:/dev/raw1394 --volume=$mount_volume:/workspace --restart=always --name=$DLSDK_CAFFE_CONTAINER_NAME ${DLSDK_CAFFE_CONTAINER}"
    docker run -tid --net $DLSDK_NETWORK_NAME --ip $subnet_prefix.4 $dockerContProxy -e ETCD_PORT=$etcd_port -e ETCD_SERVER=$etcdHostIP --device /dev/null:/dev/raw1394 --volume=$mount_volume:/workspace --restart=always --name=$DLSDK_CAFFE_CONTAINER_NAME ${DLSDK_CAFFE_CONTAINER}
}

install_multi_node() {
    k8s_key=$(date +%s | sha256sum | head -c 32)
    k8s_key_hash=$(echo $k8s_key | base64 )

    echo "multi node installation"
    create_k8s_config_map
    mkdir -p k8s_install

    export script_path=k8s/kube-deploy
    export download_path=$SCRIPT_DIR/k8s_install
    export export service_name=dlsdk
    export set_up_service=true
    export USE_SECURE_PORT=true
    export K8S_HYPERKUBE_IMAGE=intelcorp/dl-training-tool:$DLSDK_K8S_CONTAINER_VERSION
    export K8S_BASIC_KEY=$k8s_key_hash
    export K8S_HYPERKUBE_STARTUP_SCRIPT="/setkey.sh"
    . k8s/kube-deploy/create_cluster.sh -c master

    kubectl create secret generic k8s-secret --from-literal=k8s_key="$k8s_key_hash"
    create_k8s_pods
    wait_for_pods
    js_ui_port=31000
}

create_k8s_pods() {
    cd $SCRIPT_DIR

    rm -fr  k8s/dlsdk-master.yaml
    rm -fr  k8s/caffe-master.yaml
    rm -fr  k8s/dlsdk-worker.yaml
    cp k8s/caffe-master-template.yaml k8s/caffe-master.yaml
    cp k8s/dlsdk-master-template.yaml k8s/dlsdk-master.yaml
    cp k8s/dlsdk-worker-template.yaml k8s/dlsdk-worker.yaml
    cp k8s/tf-master-template.yaml k8s/tf-master.yaml
    cp k8s/tf-worker-template.yaml k8s/tf-worker.yaml
    # Replace parameters in k8s objects files
    sed -i 's/##DLSDK_JS_CONTAINER_VERSION##/'$DLSDK_JS_CONTAINER_VERSION'/' k8s/dlsdk-master.yaml
    sed -i 's/##DLSDK_CAFFE_CONTAINER_VERSION##/'$DLSDK_CAFFE_CONTAINER_VERSION'/' k8s/caffe-master.yaml
    sed -i 's/##DLSDK_CAFFE_CONTAINER_VERSION##/'$DLSDK_CAFFE_CONTAINER_VERSION'/' k8s/dlsdk-worker.yaml
    sed -i 's/##DLSDK_TF_CONTAINER_VERSION##/'$DLSDK_TF_CONTAINER_VERSION'/' k8s/tf-master.yaml
    sed -i 's/##DLSDK_TF_CONTAINER_VERSION##/'$DLSDK_TF_CONTAINER_VERSION'/' k8s/tf-worker.yaml


    sed -i 's|##USER_DIR##|'$dl_folder'|' k8s/dlsdk-master.yaml
    sed -i 's|##USER_DIR##|'$dl_folder'|' k8s/caffe-master.yaml
    sed -i 's|##USER_DIR##|'$dl_folder'|' k8s/dlsdk-worker.yaml
    sed -i 's|##USER_DIR##|'$dl_folder'|' k8s/tf-worker.yaml
    sed -i 's|##USER_DIR##|'$dl_folder'|' k8s/tf-master.yaml

    # Delete k8s old objects if exists
    kubectl delete configmap dlsdk-config 2> /dev/null | true
    kubectl delete deployment caffe-master  2> /dev/null| true
    kubectl delete deployment dlsdk-master  2> /dev/null| true
    kubectl delete deployment tf-master  2> /dev/null| true
    kubectl delete daemonset caffe-worker  2> /dev/null| true
    kubectl delete daemonset tf-worker  2> /dev/null| true
    kubectl delete service dlsdk-service  2> /dev/null| true
    kubectl delete service caffe-service  2> /dev/null | true
    kubectl delete service tf-service  2> /dev/null | true
    # create config-map
    kubectl create -f k8s/dlsdk.config
    # create dlsdk-master
    kubectl create -f k8s/dlsdk-master.yaml
    # create caffe master
    kubectl create -f k8s/caffe-master.yaml



    # Create tf-master
    kubectl create -f k8s/tf-master.yaml

    # create TF-worker
    kubectl create -f k8s/tf-worker.yaml


    # create caffe daemonset workers
    kubectl create -f k8s/dlsdk-worker.yaml
    # create services
    kubectl create -f k8s/dlsdk-service.yaml
    kubectl create -f k8s/caffe-service.yaml
    kubectl create -f k8s/tf-service.yaml

    kubectl create -f k8s/tf-borad-service.yaml

    #remove K8S UI
    if [ -z $DEV ]; then
        remove_k8s_dashboard
    fi
    mkdir -p $dl_folder/dlsdk
    mkdir -p $dl_folder/dlsdk/k8s_install
    cp -f $SCRIPT_DIR/install_training_tool.sh $dl_folder/dlsdk/k8s_install
    cp -rf $SCRIPT_DIR/k8s/kube-deploy/* $dl_folder/dlsdk/k8s_install
    ##cp -f /var/lib/dlsdk/k8s_service.sh  $dl_folder/dlsdk/k8s_install
    echo "export dl_folder=$dl_folder" >> $dl_folder/dlsdk/k8s_install/k8sconfig.sh
    echo "export DLSDK_CAFFE_CONTAINER_VERSION=$DLSDK_CAFFE_CONTAINER_VERSION" >> $dl_folder/dlsdk/k8s_install/k8sconfig.sh
    echo "export DLSDK_TF_CONTAINER_VERSION=$DLSDK_TF_CONTAINER_VERSION" >> $dl_folder/dlsdk/k8s_install/k8sconfig.sh
    echo "export DLSDK_K8S_CONTAINER_VERSION=$DLSDK_K8S_CONTAINER_VERSION" >> $dl_folder/dlsdk/k8s_install/k8sconfig.sh
    chown -R $USER_NAME:$GROUP_NAME $dl_folder || true

    open_firewall
}


remove_k8s_dashboard(){
    MAX_NUBER_OF_TIMES=3
    INDEX_NUM=0
    service_deleted=false
    while [ $INDEX_NUM -lt $MAX_NUBER_OF_TIMES ] && [ $service_deleted == "false" ];
    do
        sleep 3
        INDEX_NUM=$((INDEX_NUM + 1))
        if kubectl get service  --namespace kube-system | grep -q kubernetes-dashboard ; then
            kubectl delete service kubernetes-dashboard --namespace kube-system || true
        else
            service_deleted=true
        fi
    done

}
open_firewall(){
    if [ -n "$(command -v firewall-cmd)" ]; then #centos 07 only
        if firewall-cmd --state | grep -v "not running" | grep -q running; then
            # Job Server UI port
            firewall-cmd --permanent --add-port=31000/tcp
            # kube-proxy redirects
            firewall-cmd --permanent --direct --add-rule ipv4 filter INPUT 1 -i docker0 -j ACCEPT -m comment --comment "kube-proxy redirects"
            # docker subnet
            firewall-cmd --permanent --direct --add-rule ipv4 filter FORWARD 1 -o docker0 -j ACCEPT -m comment --comment "docker subnet"
            firewall-cmd --reload
        fi
    fi

}
MAX_WAIT_TIME=120
#This function will wait until all pods are ready
wait_for_pods(){

    check_time=0
    server_ready=false
    while [ $check_time -lt $MAX_WAIT_TIME ] && [ $server_ready == "false" ];
    do
        echo "validating setup.."
        sleep 10
        check_time=$((check_time + 10))

        if kubectl get pods |grep caffe-master|grep "1/1" | grep -q Running ;  then
            server_ready=true
        else
            server_ready=false
        fi
        if kubectl get pods |grep dlsdk-master|grep "1/1" | grep -q Running ;  then
            server_ready=true
        else
            server_ready=false
        fi
        if kubectl get pods |grep tf-master|grep "1/1" | grep -q Running ;  then
            server_ready=true
        else
            server_ready=false
        fi
    done
    if [ $server_ready == "true" ]; then
        echo "Server is ready!"
    else
        echo "Server setup failed!!"
        exit -1
    fi
}

wait_for_web_servers() {
    check_time=0
    server_ready=false
    caffe_server_ready=false;
    tf_server_ready=false;
    printf "validating setup"
    while [ $check_time -lt 240 ] && [ $server_ready == "false" ];
    do
        sleep 10
        printf "."
        check_time=$((check_time + 10))

        if [[ $type = "single" ]]; then
            tf_container_name=$(docker ps -q --filter "name=^/${DLSDK_TF_CONTAINER_NAME}$")
            caffe_container_name=$(docker ps -q --filter "name=^/${DLSDK_CAFFE_CONTAINER_NAME}$")
        else
            tf_container_name=$(docker ps | grep intelcorp/dl-training-tool:tf | awk '{print $1}')
            caffe_container_name=$(docker ps | grep intelcorp/dl-training-tool:caffe | awk '{print $1}')
        fi

        caffePorts=$( docker exec $caffe_container_name bash -c "netstat -tulenp | awk '{print $4}' | grep 8000 | wc -l" )
        tfPorts=$( docker exec $tf_container_name bash -c "netstat -tulenp | awk '{print $4}' | grep 8010 | wc -l" )

        if [[ "$caffePorts" == *"1"* ]]; then
            caffe_server_ready=true
        fi
        if [[ "$tfPorts" == *"1"* ]]; then
            tf_server_ready=true
        fi

        if [ "$caffe_server_ready" == "true" ] && [ "$tf_server_ready" == "true" ]; then
            server_ready=true
        fi
    done
    if [ "$server_ready" == "true" ]; then
        echo "Web Servers are up!"
    else
        echo "Web Servers failed to start!!"
        exit -1
    fi
}

create_k8s_config_map() {
    rm -f k8s/dlsdk.config

    inet=$(route|grep default | awk '{print $8}')
    hostMachineIP=$(ifconfig ${inet} | grep "inet"|  awk 'NR==1{ print $2}' | cut -d':' -f2)

    echo "kind: ConfigMap" >> k8s/dlsdk.config
    echo "apiVersion: v1" >> k8s/dlsdk.config
    echo "metadata:" >> k8s/dlsdk.config
    echo "  name: dlsdk-config" >> k8s/dlsdk.config
    echo "  namespace: default" >> k8s/dlsdk.config
    echo "data:" >> k8s/dlsdk.config
    echo "  ETCD_SERVER: \"$hostMachineIP\"" >> k8s/dlsdk.config
    echo "  DLSDK_SELF_SIGNED_CERTIFICATE_ALLOW: \"$self_sign_certificate\"" >> k8s/dlsdk.config
    echo "  DLSDK_PFXCERTIFICATE_ALLOW: \"$pfx_certificate\"" >> k8s/dlsdk.config
    echo "  DLSDK_PFXCERTIFICATE_PATH: \"$pfx_certificate_path\"" >> k8s/dlsdk.config
    echo "  DLSDK_PFXCERTIFICATE_PASSWORD: \"$pfx_certificate_password\"" >> k8s/dlsdk.config
    echo "  DLSDK_FILTER_ALLOW: \"$DLSDK_FILTER_ALLOW\"" >> k8s/dlsdk.config
    echo "  DLSDK_USER_ADMIN: \"$toolpasswordhash\"" >> k8s/dlsdk.config
    echo "  HTTP_PROXY: \"$http_proxy\"" >> k8s/dlsdk.config
    echo "  HTTPS_PROXY: \"$https_proxy\"" >> k8s/dlsdk.config
    echo "  MASTER_IP: \"$hostMachineIP\"" >> k8s/dlsdk.config
}

install_single_node() {
    echo "single node installation"

    create_docker_network

    if [[ $ID = "macos" ]]; then
        mount_volume="dlgvol"
    else
        mount_volume=$dl_folder
    fi

    install_etcd
    install_caffe
    install_tensorflow
    install_job_server
}

if [[ ! `uname -s | grep "Darwin"` ]]; then
    if ! [ $(id -u) = 0 ]; then
       echo "root permissions are required to run this script"
       exit 1
    fi
fi

SHOW_VERSION

#initialize docker name
if [ "$DLSDK_CAFFE_CONTAINER_NAME" = "" ]
then
   DLSDK_CAFFE_CONTAINER_NAME=trainingtool-caffe
fi
DLSDK_CAFFE_CONTAINER_NAME_INSTL=${DLSDK_CAFFE_CONTAINER_NAME}_install

if [ "$DLSDK_CAFFE_CONTAINER_VERSION" = "" ]
then
  DLSDK_CAFFE_CONTAINER_VERSION=caffe-release4-mlsl-latest
fi

DLSDK_CAFFE_CONTAINER=intelcorp/dl-training-tool:${DLSDK_CAFFE_CONTAINER_VERSION}
echo DLSDK_CAFFE_CONTAINER: $DLSDK_CAFFE_CONTAINER


#TenforFlow
#initialize docker name
if [ "$DLSDK_TF_CONTAINER_NAME" = "" ]
then
   DLSDK_TF_CONTAINER_NAME=trainingtool-tf
fi
DLSDK_TF_CONTAINER_NAME_INSTL=${DLSDK_TF_CONTAINER_NAME}_install
if [ "$DLSDK_TF_CONTAINER_VERSION" = "" ]
then
  DLSDK_TF_CONTAINER_VERSION=tf-release4-latest
fi
DLSDK_TF_CONTAINER=intelcorp/dl-training-tool:${DLSDK_TF_CONTAINER_VERSION}
echo DLSDK_TF_CONTAINER: $DLSDK_TF_CONTAINER

#NodeJS
if [ "$DLSDK_JS_CONTAINER_NAME" = "" ]
then
   DLSDK_JS_CONTAINER_NAME=trainingtool-js
fi
DLSDK_JS_CONTAINER_NAME_INSTL=${DLSDK_JS_CONTAINER_NAME}_install
if [ "$DLSDK_JS_CONTAINER_VERSION" = "" ]
then
  DLSDK_JS_CONTAINER_VERSION=js-release4-latest
fi
DLSDK_JS_CONTAINER=intelcorp/dl-training-tool:${DLSDK_JS_CONTAINER_VERSION}
echo DLSDK_JS_CONTAINER: $DLSDK_JS_CONTAINER

#ETCD
if [ "$DLSDK_ETCD_CONTAINER_NAME" = "" ]
then
   DLSDK_ETCD_CONTAINER_NAME=trainingtool-etcd
fi
DLSDK_ETCD_CONTAINER=intelcorp/dl-training-tool:etcd
echo DLSDK_ETCD_CONTAINER: $DLSDK_ETCD_CONTAINER

export PATH=$PATH:/usr/local/bin

#K8S
if [ "$DLSDK_K8S_CONTAINER_VERSION" = "" ]
then
    DLSDK_K8S_CONTAINER_VERSION=k8s-latest
fi

#check system requirements
if [[ -f "/etc/os-release" ]]; then
    . /etc/os-release
elif [[ -f "/etc/centos-release" ]] && [[ `cat /etc/centos-release | grep "CentOS"` ]]; then
    ID=centos
    VERSION_ID=$(cat /etc/centos-release | grep -oE '[0-9]+\.[0-9]+')
elif [[ `uname -s | grep "Darwin"` ]]; then
    ID=macos
    VERSION_ID=$(sw_vers -productVersion)
else
    printf "Unsupported OS distribution.\nOny Ubuntu, CentOS, CoreOS and macOS are supported\n"
    exit 0
fi

echo OS: $ID
echo Version: $VERSION_ID
VER=$(awk -F . '{print $1}' <<< "$VERSION_ID")
if [[ $ID = "macos" ]]; then
    VER=$(awk -F . '{print $2}' <<< "$VERSION_ID")
fi

if [[ ! "x$SUDO_USER" == "x" ]]; then
    username=$SUDO_USER

    if [ ! -n "$http_proxy" ]; then
        if [[ ! $ID = "macos" ]]; then
        # read proxy settings from /etc/environment, bacause sudo command removes user's environment
            while read -r line; do
                if [[ $line == *"proxy"* ]]; then
                    line=`echo $line | sed -e "s/\"//g"`
                    echo "export $line"
                    export "$line"
                fi
            done < "/etc/environment"
        fi
    fi
else
    username=$USER
fi

userHome=$(eval echo ~$(echo $username))
dockerConfigLocation="/etc/default/docker"

if [[ ! $ID = "ubuntu" && ! $ID = "centos" && ! $ID = "coreos" && ! $ID = "macos" && ! $ID = "sles" ]];then
    printf "Unsupported OS distribution.\nOny Ubuntu, CentOS, CoreOS, SUSE and macOS are supported\n"
    exit 0
fi

if [[ $ID = "ubuntu" && $VER -lt "12" ]];then
    printf "Unsupported OS distribution.\nUbuntu distribution version must be 12 and above\n"
    exit 0
fi

if [[ $ID = "macos" && $VER -lt "10" ]];then
    printf "Unsupported OS distribution.\nmacOS version must be 10.10.3 and above\n"
    exit 0
fi

if [[ $ID = "centos" && $VER -lt "7" ]];then
   printf "Unsupported OS distribution.\nCentOS distribution version must be 7 and above\n"
   exit 0
fi

if [[ $ID = "sles" && $VER -lt "12" ]];then
   printf "Unsupported OS distribution.\nSUSE distribution version must be 12 and above\n"
   exit 0
fi

current_kern_ver="$(uname -r | awk '{print substr ($0, 0, 6)}')"
required_kern_ver="3.10.0"

if [[ ! $ID = "macos" ]];then
    if [ "$(printf "$required_kern_ver\n$current_kern_ver" | sort -V | head -n1)" == "$current_kern_ver" ] && [ "$current_kern_ver" != "$required_kern_ver" ]; then
       printf "Unsupported kernel version.\nKernel minimum version must be 3.10 and above\n"
       exit 0
    fi
fi

if [ $# -eq 0 ]
  then
    SHOW_LICENSE
    echo
fi

# stage 1 - install docker tool
# stage 2 - pull docker image for training tool
# stage 3 - stop docker containers
# stage 4 - execute validation for ports for k8s
# stage 5 - run docker container
stage="12345"
type="multi"

js_ui_port="8080"
js_jupyter_caffe_port="8081"
js_jupyter_tf_port="8082"

caffe_rest_port="8000"
caffe_jupyter_port="8001"
tf_rest_port="8010"
tf_jupyter_port="8888"
etcd_port="4001"

# parse command line options
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    -h | -help | --help)
    usage
    ;;
    -username)
    username="$2"
    echo username = "${username}"
    shift
    ;;
    -volume)
    dl_volume="$2"
    echo volume=$dl_volume
    shift
    ;;
    -toolpassword)
    toolpassword="$2"
    shift
    ;;
    -startport)
    js_ui_port="$2"
    js_jupyter_caffe_port=$((js_ui_port+1))
    js_jupyter_tf_port=$((js_jupyter_caffe_port+1))

    echo js_ui_port=$js_ui_port
    echo js_jupyter_caffe_port=$js_jupyter_caffe_port
    echo js_jupyter_tf_port=$js_jupyter_tf_port
    echo caffe_rest_port=$caffe_rest_port
    echo caffe_jupyter_port=$caffe_jupyter_port
    echo tf_rest_port=$tf_rest_port
    echo etcd_port=$etcd_port
    shift
    ;;
    -toolpasswordhash)
    toolpasswordhash="$2"
    shift
    ;;
    -httpproxy)
    httpproxy="$2"
    echo httpproxy = "${httpproxy}"
    export http_proxy=$httpproxy
    shift
    ;;
    -httpsproxy)
    httpsproxy="$2"
    echo httpsproxy = "${httpsproxy}"
    export https_proxy=$httpsproxy
    shift
    ;;
    -selfsigncertificate)
    selfsigncertificate="$2"
    echo selfsigncertificate = "${selfsigncertificate}"
    export self_sign_certificate=$selfsigncertificate
    shift
    ;;
    -pfxcertificate)
    pfxcertificate="$2"
    echo pfxcertificate = "${pfxcertificate}"
    export pfx_certificate=$pfxcertificate
    shift
    ;;
    -pfxcertificatepath)
    pfxcertificatepath="$2"
    echo pfxcertificatepath = "${pfxcertificatepath}"
    export pfx_certificate_path="${pfxcertificatepath##*/}"
    export pfx_certificate=true
    shift
    ;;
    -pfxcertificatepassword)
    pfxcertificatepassword="$2"
    export pfx_certificate_password=$pfxcertificatepassword
    shift
    ;;
    -stage)
    stage="$2"
    ui_installer=true
    echo stage = "${stage}"
    shift
    ;;
    -type)
    type="$2"
    echo type = "${type}"
    export type=$type
    shift
    ;;
    *)
    # unknown option
    ;;
esac
shift # past argument or value
done

if [[ $type = "multi" && $ID = "macos" ]];then
#if [[ $type = "multi" ]];then
#    if [[ $ID = "macos" || $ID = "sles" ]];then
        type="single"
        echo "Multi-node mode is not supported on $ID. Switching to single-node mode."
#    fi
fi

if [[ ! -n $toolpassword && ! -n $toolpasswordhash && "$stage" == *"5"* ]]; then
    read -p "Please enter password to access the Training Tool web interface: [admin] " toolpassword
    toolpassword=${toolpassword:-admin}
fi
if [ -d k8s ]; then
    chmod +x k8s/*.sh
    chmod +x k8s/kube-deploy/*.sh
    chmod +x k8s/kube-deploy/docker-multinode/*.sh
fi

install_docker() {
    dockerProxy='Environment='
    dockerContProxy=''
    isDockerProxyNeeded=false

    if [ -n "$http_proxy" ]; then
        if [[ ! `cat $userHome/.bashrc | grep "export http_proxy="` ]]; then
            echo "export http_proxy='$http_proxy'" >> $userHome/.bashrc
        fi
        dockerProxy=$dockerProxy"HTTP_PROXY=$http_proxy"
        dockerContProxy=$dockerContProxy"-e http_proxy=$http_proxy"
        isDockerProxyNeeded=true
    fi

    if [ -n "$https_proxy" ]; then
        if [[ ! `cat $userHome/.bashrc | grep "export https_proxy="` ]]; then
            echo "export https_proxy='$https_proxy'" >> $userHome/.bashrc
        fi
        dockerProxy="$dockerProxy HTTPS_PROXY=$https_proxy"
        dockerContProxy=$dockerContProxy" -e https_proxy=$https_proxy"
        isDockerProxyNeeded=true
    fi

    #install docker-engine if not installed or old version is installer
    if command -v docker >/dev/null 2>&1; then
      echo "docker is already installed"
      server_version=$(docker version --format '{{.Server.Version}}') || true
      client_version=$(docker version --format '{{.Client.Version}}') || true
      echo "docker server version is $server_version"
      echo "docker client version is $client_version"
    fi

    if ! command -v docker >/dev/null 2>&1 || version_gt "1.12" "$server_version" || version_gt "1.12" "$client_version"; then
        if [[ ! $ID = "macos" ]]; then
            echo "let's install latest version of docker"

            if [[ $ID = "centos" ]];then
                # Remove packages which conflict with the official docker-engine package on CentOS
                yum -y remove docker docker-common container-selinux docker-selinux
            fi

            if [[ $ID = "sles" ]];then
                echo "Install docker for SUSE"
                zypper install -y docker
                systemctl enable docker.service
            else
                curl -fsSL https://get.docker.com/ | sh
            fi
            usermod -aG docker $username
            if ! service docker status | grep running; then
                service docker start
            fi
        else
            echo "Please install \"Docker for Mac\""
            exit
        fi
    fi

    if [[ ! $ID = "macos" ]]; then
        echo "isDockerProxyNeeded = $isDockerProxyNeeded"
        #update docker conf with proxy if proxy defined
        if [[ $ID = "ubuntu" && $VER -lt "15" ]];then
            if [[ -n "$http_proxy" && ! `cat $dockerConfigLocation | grep "export http_proxy"` ]]; then
                echo "setting http proxy for docker (upstart)"
                sh -c 'echo "export http_proxy='$http_proxy'" >> '$dockerConfigLocation''
                echo "sh -c 'echo "export http_proxy='$http_proxy'" >> '$dockerConfigLocation''"
                service docker restart
            fi
            if [[ -n "$https_proxy" && ! `cat $dockerConfigLocation | grep "export https_proxy"` ]]; then
                echo "setting https proxy for docker (upstart)"
                sh -c 'echo "export https_proxy='$https_proxy'" >> '$dockerConfigLocation''
                echo "sh -c 'echo "export https_proxy='$https_proxy'" >> '$dockerConfigLocation''"
                service docker restart
            fi
        else
            if [[ $isDockerProxyNeeded="true" && ! `cat /etc/systemd/system/docker.service.d/http-proxy.conf | grep "HTTPS_PROXY"` ]];then
                echo "setting proxy for docker (systemd)"
                sh -c 'mkdir -p /etc/systemd/system/docker.service.d'
                sh -c 'echo [Service]' > /etc/systemd/system/docker.service.d/http-proxy.conf
                sh -c 'echo '$dockerProxy'' >> /etc/systemd/system/docker.service.d/http-proxy.conf
                systemctl daemon-reload
                service docker restart
            fi
        fi
    fi

    if command -v docker >/dev/null 2>&1; then
        echo "docker installation finished"
    fi
}

execute_command_with_retry() {
    n=0
    max=5
    echo "$@"
    until [ $n -ge $max ]
    do
        "$@" && break
        echo "Command $@ failed. Attempt $n/$max:"
        n=$[$n+1]
        sleep 5
    done
}

pull_images() {
    # pull docker image
    if [[ "$stage" == "2" ]];then
        # 'Tee' command needed for less verbose output
        set -o pipefail
        execute_command_with_retry docker pull ${DLSDK_CAFFE_CONTAINER} | tee
        execute_command_with_retry docker pull ${DLSDK_TF_CONTAINER} | tee
        execute_command_with_retry docker pull ${DLSDK_JS_CONTAINER} | tee
        execute_command_with_retry docker pull ${DLSDK_ETCD_CONTAINER} | tee
        set +o pipefail
    else
        # use more verbose output when the script is run manually
        execute_command_with_retry docker pull ${DLSDK_CAFFE_CONTAINER}
        execute_command_with_retry docker pull ${DLSDK_TF_CONTAINER}
        execute_command_with_retry docker pull ${DLSDK_JS_CONTAINER}
        execute_command_with_retry docker pull ${DLSDK_ETCD_CONTAINER}
    fi

    echo "docker pull completed"
}

stop_containers() {
    #stop previous training tool containers
    remove_container $DLSDK_CAFFE_CONTAINER_NAME
    remove_container $DLSDK_CAFFE_CONTAINER_NAME_INSTL
    remove_container "dlgenie"
    remove_container "trainingtool"
    remove_container $DLSDK_TF_CONTAINER_NAME
    remove_container $DLSDK_TF_CONTAINER_NAME_INSTL
    remove_container $DLSDK_JS_CONTAINER_NAME
    remove_container $DLSDK_JS_CONTAINER_NAME_INSTL
    remove_container $DLSDK_ETCD_CONTAINER_NAME

    if [[ ! $ID = "macos" ]];then
        cd $SCRIPT_DIR
        export script_path=k8s/kube-deploy
        export download_path=$SCRIPT_DIR/k8s_install
        export export service_name=dlsdk
        . k8s/kube-deploy/create_cluster.sh -c remove || true
        cd $SCRIPT_DIR
    fi

    echo "stop containers completed"
}

setup_user_folder(){
    isUpgrade=0
    if [ -n "$dl_volume" ]; then
        dl_folder=$dl_volume/dlsdk/
        if [ -d "$dl_volume/dl-genie" ] && [ ! -d "$dl_volume/dlsdk" ]; then
            isUpgrade=1
            echo move "$dl_volume/dl-genie" to "$dl_volume/dlsdk"
            mv -fv "$dl_volume/dl-genie" "$dl_volume/dlsdk"
        fi
    else
        dl_folder=$userHome/dlsdk/
        if [ -d "$userHome/dl-genie" ] && [ ! -d "$userHome/dlsdk" ]; then
            isUpgrade=1
            echo move "$userHome/dl-genie" to "$userHome/dlsdk"
            mv -fv "$userHome/dl-genie" "$userHome/dlsdk"
        fi
    fi
    echo "mkdir -p $dl_folder"
    mkdir -p $dl_folder
    create_user

    if [[ $ID = "macos" ]]; then
        if [[ ! `docker volume ls | grep "dlgvol$"` ]]; then
            docker volume create --name=dlgvol
        fi
    fi
    if [[ ! $ID = "macos" ]];then
        rm -f $dl_folder/dlsdk/security/security.properties
        if [ "$ui_installer" == "true" ]; then
            echo "mkdir -p $dl_folder/dlsdk/security"
            mkdir -p $dl_folder/dlsdk/security
            touch $dl_folder/dlsdk/security/.showPassword
        fi

        echo "chown -R $USER_NAME:$GROUP_NAME $dl_folder"
        chown -R $USER_NAME:$GROUP_NAME $dl_folder
    fi
}
run_containers() {
    setup_user_folder

    if [[ "x$toolpasswordhash" == "x" ]] ; then
        if command -v shasum >/dev/null 2>&1; then
            toolpasswordhash=$(echo -n admin:$toolpassword | shasum -a 256 | cut -d ' ' -f 1)
        elif command -v sha256sum >/dev/null 2>&1; then
            toolpasswordhash=$(echo -n admin:$toolpassword | sha256sum | cut -d ' ' -f 1)
        else
            echo "no sha library exists, please install shasum, or sha256sum"
        fi
    fi

    protocol=http

    #initialize fillter.allow
    if [ "$DLSDK_FILTER_ALLOW" = "" ]
    then
       DLSDK_FILTER_ALLOW="/favicon;/css;/js;/img;/fonts"
    fi

    #https certificates
    if [ "$pfx_certificate" = "true" ]; then
        protocol=https
        echo "cp $pfxcertificatepath $dl_folder/$pfx_certificate_path"
        cp $pfxcertificatepath $dl_folder/$pfx_certificate_path
    fi

    if [[ $type = "single" ]]; then
        install_single_node
    elif [[ $type = "multi" ]]; then
        install_multi_node
    fi

    wait_for_web_servers

    echo $?
    echo "Training Tool installation completed"
    if [[ ! $ID = "macos" ]];then
        echo "Now you can open $protocol://<linux_hostname>:$js_ui_port address in Chrome browser to start using the Training Tool"
    else
        echo "Now you can open $protocol://localhost:$js_ui_port address in Chrome browser to start using the Training Tool. "
        if [[ $isDockerProxyNeeded="true" ]]; then
            echo "If you are behind proxy, don't forget to add exception for \"localhost\" address in the network settings"
        fi
    fi
}

validate_ports() {
    echo "validating ports"

    if [[ ! $ID = "macos" ]];then

        cd $SCRIPT_DIR
        . k8s/ports.sh
        if [[ $type = "multi" ]];then
            validate_ports 8080 8081 8082 4001 2380 2379 8285 10252 10255 4194 10250 6443 10251
        else
            validate_ports $js_ui_port $js_jupyter_caffe_port $js_jupyter_tf_port
        fi

        if [ ! -z "$busy_ports_output" ]; then
            echo $busy_ports_output
            echo "The following ports which are required for DL-SDK installation are occupied"
            echo $busyports
            echo "Please free the required ports and rerun the installation"
            echo "Optionally you can install DL-SDK for single node only"
        fi
    fi

    echo "ports validation completed"
}

if [[ "$stage" == *"1"* && ! $ID = "coreos" ]];then
    install_docker
fi

if [[ "$stage" == *"2"* ]];then
    pull_images
fi

if [[ "$stage" == *"3"* ]];then
    stop_containers
fi

if [[ "$stage" == *"4"* ]];then
    validate_ports
fi

if [[ "$stage" == *"5"* ]];then
    run_containers
fi

if [[ "$stage" == *"6"* ]];then
    setup_user_folder
fi