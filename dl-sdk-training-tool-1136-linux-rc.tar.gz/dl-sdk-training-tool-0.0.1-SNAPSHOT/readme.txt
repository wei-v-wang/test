install_training_tool.sh - installs the Training Tool to Linux or macOS system locally

uninstall_training_tool.sh - removes the Training Tool from local Linux or macOS system

reset_tool_password.sh - resets a password to access the web interface of the Training Tool

To see the list of command line options for the install scripts, run "<install_script_name> -help".

Supported Linux systems: Ubuntu 14.04 or higher, Cent OS 7, CoreOS
Supported MacOS systems: 10.10.3 or higher with installed "Docker for Mac" tool