#!/bin/bash

#               INTEL CORPORATION PROPRIETARY INFORMATION
#  This software is supplied under the terms of a license agreement or
#  nondisclosure agreement with Intel Corporation and may not be copied
#  or disclosed except in accordance with the terms of that agreement.
#        Copyright (c) 2016-2017 Intel Corporation. All Rights Reserved.

# This script resets password for the Training Tool web interface
# User name is always "admin" and cannot be changed

#check system requirements
if [[ -f "/etc/os-release" ]]; then
    . /etc/os-release
elif [[ -f "/etc/centos-release" ]] && [[ `cat /etc/centos-release | grep "CentOS"` ]]; then
    ID=centos
    VERSION_ID=$(cat /etc/centos-release | grep -oE '[0-9]+\.[0-9]+')
elif [[ `uname -s | grep "Darwin"` ]]; then
    ID=macos
    VERSION_ID=$(sw_vers -productVersion)
fi

update_password() {
    if [[ ! $ID = "macos" ]];then
        echo "updating $@/dlsdk/security/security.properties file"
        rm -f $@/dlsdk/security/security.properties
        echo "user.admin=${toolpasswordhash}\:Admin" > $@/dlsdk/security/security.properties
        echo "filter.allow=/favicon;/css;/js;/img;/fonts" >> $@/dlsdk/security/security.properties

        chown -R dlsdk-user:dlsdk-group $@/dlsdk/security/
    else
        container_id=$(docker ps -q --filter "name=^/${DLSDK_JS_CONTAINER_NAME}$")

        docker exec -u 0 $container_id sh -c "rm -f /workspace/dlsdk/security/security.properties"
        docker exec -u 0 $container_id sh -c "echo \"user.admin=${toolpasswordhash}\:Admin\" > /workspace/dlsdk/security/security.properties"
        docker exec -u 0 $container_id sh -c "echo \"filter.allow=/favicon;/css;/js;/img;/fonts\" >> /workspace/dlsdk/security/security.properties"

        docker exec -u 0 $container_id sh -c "chown -R dlsdk:docker /workspace"
    fi
}

if ! [ $(id -u) = 0 ]; then
   echo "root permissions are required to run this script"
   exit 1
fi

read -p "Please enter new password to access the Training Tool web interface: [admin] " toolpassword
toolpassword=${toolpassword:-admin}

if command -v shasum >/dev/null 2>&1; then
    toolpasswordhash=$(echo -n admin:$toolpassword | shasum -a 256 | cut -d ' ' -f 1)
else
    toolpasswordhash=$(echo -n admin:$toolpassword | sha256sum | cut -d ' ' -f 1)
fi

type=multi
if command -v kubectl >/dev/null 2>&1; then
    if docker ps | grep -q gcr.io/google_containers/hyperkube-amd64 && kubectl get pods | grep -q dlsdk-master; then
        echo "k8s running"
        pod_name=$(kubectl get pods | grep dlsdk-master | awk '{print $1}')

        hostPath=$(kubectl describe pod $pod_name| grep Path: | head -1)
        hostPath=${hostPath#*Path:}

        update_password $hostPath
        kubectl delete pod $(kubectl get pods | grep dlsdk-master | awk '{print $1}')
    else
        echo "not running k8s"
        type=single
    fi
else
    echo "no kubectl detected"
    type=single
fi

if [ $type == "single" ]; then
    if [ "$DLSDK_JS_CONTAINER_NAME" = "" ]
    then
       DLSDK_JS_CONTAINER_NAME=trainingtool-js
    fi
    volumePath=$(docker inspect --format '{{ range .Mounts }}{{ .Source }}{{ end }}' $DLSDK_JS_CONTAINER_NAME)

    update_password $volumePath
    echo "restarting docker container with training tool..."
    docker restart $DLSDK_JS_CONTAINER_NAME
fi
echo "done"